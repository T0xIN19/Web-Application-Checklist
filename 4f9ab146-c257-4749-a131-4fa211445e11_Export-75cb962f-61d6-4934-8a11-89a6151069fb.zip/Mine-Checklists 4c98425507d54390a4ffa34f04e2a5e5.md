# Mine-Checklists

- [ ]  wayback url | tee -a 1.txt
- [ ]  katana -u url | tee -a 2.txt
- [ ]  gau url | tee -a 3.txt
- [ ]  subfinder -d url | tee -a 4.txt
- [ ]  sublist3r -d url -o 5.txt
- [ ]  go run main.go -d [target.com](http://target.com/) -s nNFkGl0oOThcTBCa6mURW8FRUdekImV9 ——

[GitHub - incogbyte/shosubgo: Small tool to Grab subdomains using Shodan api.](https://github.com/incogbyte/shosubgo?tab=readme-ov-file)

- [ ]  chaos -silent -d [example.com](http://example.com/) | tee 7.txt - 7443bce5-4253-472b-9ec1-08f2a0eff74b
- [ ]  go run main.go -d [target.com](http://target.com/) -s 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
- [ ]  amass enum -d [example.com](http://example.com/)  -o .txt
- [ ]  altdns -i subdomains.txt -o data_output -w words.txt -r
- [ ]  python3 crawler.py
- [ ]  [https://tools.whoisxmlapi.com/reverse-whois-search](https://tools.whoisxmlapi.com/reverse-whois-search) :-  to find tech domain related domains
- [ ]  go run main.go -d domain.com -o /home/inam/target/makemytrip/gitrecon.txt
- [ ]  ffuf -u "" -w /home/inam/Documents/Word-lists/best-dns-wordlist.txt -o fuzz.txt
- [ ]  wc 1.txt & wc 2.txt
- [ ]  cat *.txt >> lista.txt
- [ ]  cat lista.txt | sort | uniq > list.txt
- [ ]  wc list.txt
- [ ]  cat list.txt | httpx -mc 200 > working.txt (options)we
- [ ]  nmap -iL working_gopro.txt -p0-65535 -oN fullscan_gopro.txt (options)
- [ ]  ibrahim tools
- [ ]  cat gitrecon.txt | dnsx -a -resp-only | nrich -  (convert domain into ip using shodan)
- [ ]  cat list.txt | httpx —content-lenght —status-code (choose the target)
- [ ]  nuclei -t fuzzing-templates -list fuzz_endpoints.txt
- [ ]